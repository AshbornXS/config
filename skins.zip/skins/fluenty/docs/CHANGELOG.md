# [1.3.0](https://github.com/shdwmtr/fluenty/compare/v1.2.0...v1.3.0) (2024-09-15)


### Bug Fixes

* Fix library sidebar not filling entire area. ([fb118ce](https://github.com/shdwmtr/fluenty/commit/fb118ceb93d174f0c4f9536b0797cf01e0261235))
* Fix visual bug in collections area ([4e67759](https://github.com/shdwmtr/fluenty/commit/4e677596e049bc029f2678657949f04c83e707c8))


### Features

* Add WinUI color scheme ([89a4ab3](https://github.com/shdwmtr/fluenty/commit/89a4ab360efaa0e908c57777ed7069584adeeabc))

# [1.2.0](https://github.com/shdwmtr/fluenty/compare/v1.1.23...v1.2.0) (2024-09-14)


### Bug Fixes

* Fix bug causing Steam to not show on startup. ([b19d73d](https://github.com/shdwmtr/fluenty/commit/b19d73d91786cf25b75e9dd10b42e6d8c080547b))
* Fix hidden side bar causing search bar to improperly span. ([09e587f](https://github.com/shdwmtr/fluenty/commit/09e587f9c539f0db44d9984f0edb3dacbc787ec7))
* Fix notification bell peek not using system accent color ([f9113c6](https://github.com/shdwmtr/fluenty/commit/f9113c69d365533d1b08477d4cae548150cea8d4))
* Visual fixes for hidden games & collections ([f28b1fd](https://github.com/shdwmtr/fluenty/commit/f28b1fda12dc503cf25ada9c79c74f703df84160))


### Features

* Allow sidebar buttons to re-clicked even when active. ([1cd6366](https://github.com/shdwmtr/fluenty/commit/1cd636619939ec78071ff0dedd7841f61023c290))
* Matte play buttons & better animations. ([f1216ea](https://github.com/shdwmtr/fluenty/commit/f1216ea5801dd0fc72ea04952c5bc55110eaebf6))

## [1.1.23](https://github.com/shdwmtr/fluenty/compare/v1.1.22...v1.1.23) (2024-09-13)


### Bug Fixes

* Fix CI ([9fbdd7f](https://github.com/shdwmtr/fluenty/commit/9fbdd7f755d14c38c1f22f742c8c8dea4f764554))
* Fix sidebar buttons not changing when router moves from, ex: store to community without using inbuilt buttons ([c937b7b](https://github.com/shdwmtr/fluenty/commit/c937b7bb3e9e1e7333504a1a82de74ae7d0fad66))

## [1.1.22](https://github.com/shdwmtr/fluenty/compare/v1.1.21...v1.1.22) (2024-09-12)


### Bug Fixes

* Fix CI ([b27068f](https://github.com/shdwmtr/fluenty/commit/b27068fdaf9de39ed89c1dfbda09f17327de32c8))

## [1.1.21](https://github.com/shdwmtr/fluenty/compare/v1.1.20...v1.1.21) (2024-09-12)


### Bug Fixes

* Fix download & settings button not being interactable. ([04befb8](https://github.com/shdwmtr/fluenty/commit/04befb8b27e8c4387e197ac985b41cdc4ac79779))

## [1.1.20](https://github.com/shdwmtr/fluenty/compare/v1.1.19...v1.1.20) (2024-09-12)


### Bug Fixes

* Fix Screenshot manager ([c0965e0](https://github.com/shdwmtr/fluenty/commit/c0965e08308d4b0b769c2dce580bf75c48d07c36))

## [1.1.19](https://github.com/shdwmtr/fluenty/compare/v1.1.18...v1.1.19) (2024-09-12)


### Bug Fixes

* Separator colors & Non-steam game page fixes ([f264f41](https://github.com/shdwmtr/fluenty/commit/f264f416dbf225df688248c1a49dca7573f53de8))

## [1.1.18](https://github.com/shdwmtr/fluenty/compare/v1.1.17...v1.1.18) (2024-09-12)


### Bug Fixes

* Beta bug fixes and library text bleeding ([da6b805](https://github.com/shdwmtr/fluenty/commit/da6b805189d6dd77a92881801e198e4609891c19))

## [1.1.17](https://github.com/shdwmtr/fluenty/compare/v1.1.16...v1.1.17) (2024-09-12)


### Bug Fixes

* Fixed noSidebar search clickable ([92df4e7](https://github.com/shdwmtr/fluenty/commit/92df4e7ae3a551a5346d50b7e2d406ac89df7e7a))

## [1.1.16](https://github.com/shdwmtr/fluenty/compare/v1.1.15...v1.1.16) (2024-09-12)


### Bug Fixes

* Default bg for collection and soundtrack page ([50e1689](https://github.com/shdwmtr/fluenty/commit/50e1689973cfaf31d8d9e99b2cd5125642a4b647))
* Fixed "Library QoL" bugfix ([26e99b2](https://github.com/shdwmtr/fluenty/commit/26e99b2155f0a26854c5ec0d087d10c53ccf0499))

## [1.1.15](https://github.com/shdwmtr/fluenty/compare/v1.1.14...v1.1.15) (2024-09-12)


### Bug Fixes

* Fix friends list avatars ([b6ff4dd](https://github.com/shdwmtr/fluenty/commit/b6ff4ddd40a014441bb131e483b33fd439038aeb))

## [1.1.14](https://github.com/shdwmtr/fluenty/compare/v1.1.13...v1.1.14) (2024-09-12)


### Bug Fixes

* Fix dropdown menus ([cc67cc9](https://github.com/shdwmtr/fluenty/commit/cc67cc933659832fe5cea334c28ba39e2d7229fb))
* More classname fixes ([0e18704](https://github.com/shdwmtr/fluenty/commit/0e1870480648eef71d01165e49e1f2ffe0adefd0))

## [1.1.13](https://github.com/shdwmtr/fluenty/compare/v1.1.12...v1.1.13) (2024-09-12)


### Bug Fixes

* Screenshot Manager colors ([94851cf](https://github.com/shdwmtr/fluenty/commit/94851cf4a04f12c5d73457df01478d509bd6fa74))

## [1.1.12](https://github.com/shdwmtr/fluenty/compare/v1.1.11...v1.1.12) (2024-09-12)


### Bug Fixes

* Fix settings modal classnames ([82db1ac](https://github.com/shdwmtr/fluenty/commit/82db1ac58756fb16d6079facad622fb98970b6be))

## [1.1.11](https://github.com/shdwmtr/fluenty/compare/v1.1.10...v1.1.11) (2024-09-12)


### Bug Fixes

* Fixed Rootmenu and Traymenu ([3ce2868](https://github.com/shdwmtr/fluenty/commit/3ce2868f7d2aca6e0690ff055e99237c559d1fb3))

## [1.1.10](https://github.com/shdwmtr/fluenty/compare/v1.1.9...v1.1.10) (2024-09-11)


### Bug Fixes

* Fixed "Play Button Color" config always on ([3357a86](https://github.com/shdwmtr/fluenty/commit/3357a8662cbf47640d3b9d24f56cd2e2603e92ab))
* Library page Quality of Life patches ([a912e6b](https://github.com/shdwmtr/fluenty/commit/a912e6b394b695574f9f71bef0b3a9d80cd2eb84))

## [1.1.9](https://github.com/shdwmtr/fluenty/compare/v1.1.8...v1.1.9) (2024-09-10)


### Bug Fixes

* Fixed missing collection name ([bc7636b](https://github.com/shdwmtr/fluenty/commit/bc7636bee1de4329439b945140f3dfde40a5dd6b))
* Fixed store page search box text colors ([5df51ac](https://github.com/shdwmtr/fluenty/commit/5df51ac2462ab20182b7a26a1e3d26d73a97a8e8))

## [1.1.8](https://github.com/shdwmtr/fluenty/compare/v1.1.7...v1.1.8) (2024-09-09)


### Bug Fixes

* Fix alignment of search suggest on store page ([b53e745](https://github.com/shdwmtr/fluenty/commit/b53e74570c79998a69b87d06d16638404a482ec1))
* Fixed steam points page colors ([83a78f4](https://github.com/shdwmtr/fluenty/commit/83a78f42a722d6e380e946a554ef1bf90c898cff))
* Fixed the library search bar with "noSidebar" ([43ee938](https://github.com/shdwmtr/fluenty/commit/43ee9387493fffb31c4e60e91fc592c88f874df2))

## [1.1.7](https://github.com/shdwmtr/fluenty/compare/v1.1.6...v1.1.7) (2024-09-09)


### Bug Fixes

* Bug fixes on new sidebar config ([5321178](https://github.com/shdwmtr/fluenty/commit/532117805e0535b50b3a0c3d2ff25ea0c799fb85))
* Fix blue light leak under library sidebar from updates modal ([4bec61e](https://github.com/shdwmtr/fluenty/commit/4bec61e67c95b4d1c759c8731669f98cb5295498))
* Fix text ghosting into library sidebar ([54239f6](https://github.com/shdwmtr/fluenty/commit/54239f6e14112df24033dc2e949086661c49372b))

## [1.1.6](https://github.com/shdwmtr/fluenty/compare/v1.1.5...v1.1.6) (2024-09-09)


### Bug Fixes

* Add windows store sidebar design ([1f349e7](https://github.com/shdwmtr/fluenty/commit/1f349e7a8f2ee319ced4ce3601c4fa25df9ba53f))

## [1.1.5](https://github.com/shdwmtr/fluenty/compare/v1.1.4...v1.1.5) (2024-09-09)


### Bug Fixes

* Fix amoled color scheme ([d4b94fe](https://github.com/shdwmtr/fluenty/commit/d4b94fe781d3236148215e299fb82528df10684c))

## [1.1.4](https://github.com/shdwmtr/fluenty/compare/v1.1.3...v1.1.4) (2024-09-09)


### Bug Fixes

* profile avatar frame consistency ([43dc7e4](https://github.com/shdwmtr/fluenty/commit/43dc7e4b6ea3e7f7af10f7323196e9dc2be18341))
* wishlist page fix ([7813a65](https://github.com/shdwmtr/fluenty/commit/7813a655dfa80350029685ac538554f2ffe3ddfa))

## [1.1.3](https://github.com/shdwmtr/fluenty/compare/v1.1.2...v1.1.3) (2024-09-09)


### Bug Fixes

* Fix library not being fully scrollable ([c8f7469](https://github.com/shdwmtr/fluenty/commit/c8f7469e0b3a9ca563d6cc8fb41c8a9f2a88d397))

## [1.1.2](https://github.com/shdwmtr/fluenty/compare/v1.1.1...v1.1.2) (2024-09-04)


### Bug Fixes

* Move settings into proper tabs ([0a7b9b4](https://github.com/shdwmtr/fluenty/commit/0a7b9b44d3ac2d0465bec9c13b36cb7ea73ca23f))

## [1.1.1](https://github.com/shdwmtr/fluenty/compare/v1.1.0...v1.1.1) (2024-08-29)


### Bug Fixes

* Fix group chat visual bugs ([5de7175](https://github.com/shdwmtr/fluenty/commit/5de7175a462e324b5c8cb1df75393ab733f112b0))

# [1.1.0](https://github.com/ShadowMonster99/fluenty/compare/v1.0.0...v1.1.0) (2024-08-07)


### Bug Fixes

* avatar consistency in activity ([4c2861d](https://github.com/ShadowMonster99/fluenty/commit/4c2861d31d33b3a243da59552bdca4fed8452a80))
* community market interface bug ([29d7a5a](https://github.com/ShadowMonster99/fluenty/commit/29d7a5a255b2883d7be646fc40da99037d0cde4e))
* missing/broken icons ([242ebea](https://github.com/ShadowMonster99/fluenty/commit/242ebea88514778234094b30de820f6752641b6b))
* missing/broken icons (compact) (+) ([320f2f8](https://github.com/ShadowMonster99/fluenty/commit/320f2f869913233a6b9069e465fb5afd7943d905))
* play button and achievement accent colours ([fb0be24](https://github.com/ShadowMonster99/fluenty/commit/fb0be24c20c9101500428f48d2eb5455bd416d8b))
* various webkit issues ([b9e44b1](https://github.com/ShadowMonster99/fluenty/commit/b9e44b1af9ffd8cc01124b9709a362c08d347378))


### Features

* activity menu on sidebar ([026c594](https://github.com/ShadowMonster99/fluenty/commit/026c5945b2673038c259bbe5ca8110fd5909bafc))

# 1.0.0 (2024-07-23)


### Bug Fixes

* Remove JS unused component ([5caf2f9](https://github.com/ShadowMonster99/fluenty/commit/5caf2f927031da442f09a34e50b2caa51998ff2c))
