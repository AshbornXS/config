#!/bin/bash

# Extract the new version using grep without -P
VERSION=$(npx semantic-release --dry-run | grep -o 'The next release version is [0-9.]*' | sed 's/The next release version is //')

# Output the version
echo "Version: $VERSION"
echo "::set-output name=version::$VERSION"

# Update the version field in skin.json using jq
jq --arg version "$VERSION" '.version = $version' skin.json > tmp.json && mv tmp.json skin.json

# Commit and push the changes
git config user.email "github-actions@github.com"
git config user.name "GitHub Actions"
git add skin.json
git commit -m "chore(release): bump version to v$VERSION [skip ci]"
git push
