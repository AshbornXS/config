
/*zoom in/out keys:		-must be 1 char
/*Key to zoom in*/
export const zoomInKey = "=";
//Key to zoom out
export const zoomOutKey = "-";

/*birthday for age gate:
/*year*/
export const year = "2005";
//month
export const month = "March";
//day
export const day = "14";

export const filePathPrefix ="skins/ATOMS-main";

// Millinneum only, makes the colors match system accent color.
export const systemAccentsEnabled ="1";

/* itad api key, public use, will probably get rate limited, get your own here:
https://isthereanydeal.com/apps/my/
per:
https://docs.isthereanydeal.com/#section/Access
*/
export var itadApiKey = 'ccfb94d1e7628f4016caad5a824e9cd77981a65a';