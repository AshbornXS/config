import waitForElement from './src/js/waitForElement.js';
import { bigWait } from './src/js/utility.js';
import modifySteamRootMenu from './src/js/rootMenus/modifySteamRootMenu.js';

if (document.title == "Steam Root Menu") {
	bigWait();
	waitForElement('#popup_target', function (element) {
		waitForElement('#popup_target > div > div > div:nth-child(11)', modifySteamRootMenu);
	});
}